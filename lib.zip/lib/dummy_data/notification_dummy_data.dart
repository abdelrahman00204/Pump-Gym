const unreadNotificationCountDummyData = 6;
